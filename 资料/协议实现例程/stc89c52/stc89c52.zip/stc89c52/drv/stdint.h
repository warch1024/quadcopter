
/***********************************************************************
 * 
 * �ļ���   
 * ����     hche
 * E-mail   273039844@qq.com
 * ����     2023/09/21
 * �汾     V3.2.0
 * ˵��     
 * 
 ************************************************************************/
 

 

 


#ifndef __STDINT_H
#define __STDINT_H

typedef unsigned char            uint8_t;  
typedef unsigned short           uint16_t;
typedef unsigned long            uint32_t;
typedef signed char              int8_t;
typedef signed short             int16_t;
typedef signed long              int32_t;



#endif

