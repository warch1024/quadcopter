
#include <reg52.h>
#include "hu_m40.h"

void main()   
{
  hu_m40_init();
  
  while(1)
  {
    if (hu_m40_read() == 1) // ��������
    {
      // ҡ��ֵ
      uint8_t ly = hu_m40_analog(HU_LY);
      uint8_t lx = hu_m40_analog(HU_LX);
      uint8_t ry = hu_m40_analog(HU_RY);
      uint8_t rx = hu_m40_analog(HU_RX);
      
      // ����ֵ
      if (hu_m40_button(HU_K1))  // K1����
      {
        
      }
      if (hu_m40_button(HU_K2))  // K2����
      {
        
      }
      if (hu_m40_button(HU_K3))  // K3����
      {
        
      }
      if (hu_m40_button(HU_K4))  // K4����
      {
        
      }

    }
  }
}
